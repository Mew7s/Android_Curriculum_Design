package com.example.notesfavor.common;

import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Favors {
    public int type;//类别  0:随礼  1:送礼
    public int type2;//送礼类别 0：结婚大喜 1：新造华堂 2:金榜题名
    public Date datetime=null;//时间
    public String name;    //送礼人
    public double amount;  //金额
    public String remarks; //备注

    public Favors(int type,int tyoe2,Date date,String name,double amout,String remarks)
    {
        this.type=type;
        this.type2=type2;
        this.datetime=date;
        this.name=name;
        this.amount=amout;
        this.remarks=remarks;
    }

    public Favors()
    {
        //初始化时间（当天）
        datetime=new Date(System.currentTimeMillis());

    }
    public Favors(Favors item)
    {
        this.type=item.type;
        this.type2=item.type2;
        this.datetime=item.datetime;
        this.name=item.name;
        this.amount=item.amount;
        this.remarks=item.remarks;
    }
    public String toString()
    {
        String msg="";
        msg+="#favor#"+type;
        msg+="#"+type2;
        msg+="#"+getDateString();
        msg+="#"+name;
        msg+="#"+amount;
        msg+="#"+remarks;
        return msg;
    }
    public void analysis(String msg)
    {
        String list[]=msg.split("#");
        if(list.length>=1&&list[0]!=null&&!list[0].isEmpty())
            type=Integer.parseInt(list[0]);
        if(list.length>=2&&list[1]!=null&&!list[1].isEmpty())
            type2=Integer.parseInt(list[1]);
        if(list.length>=3&&list[2]!=null&&!list[2].isEmpty())
            datetime=Base.getDate(list[2]);
        if(list.length>=4&&list[3]!=null&&!list[3].isEmpty())
            name=list[3];
        if(list.length>=5&&list[4]!=null&&!list[4].isEmpty())
            amount=Double.parseDouble(list[4]);
        if(list.length>=6&&list[5]!=null&&!list[5].isEmpty())
            remarks=list[5];

    }
    //判断结构体中是否存在与搜索信息相似的信息
    public boolean isFindItem(String findmsg)
    {
        boolean flag=false;
        if(name.indexOf(findmsg)!=-1)
            flag=true;
        if(gettypename().indexOf(findmsg)!=-1)
            flag=true;
        if(getnamesltype2().indexOf(findmsg)!=-1)
            flag=true;
        if(getDateString().indexOf(findmsg)!=-1)
            flag=true;
        String count="￥"+amount;
        if(count.indexOf(findmsg)!=-1)
            flag=true;
        if(remarks!=null&&remarks.indexOf(findmsg)!=-1)
            flag=true;
        return flag;
    }
    public String gettypename()
    {
        String name="";
        switch(type)
        {
            case 0:
            {
                name="随礼";
                break;
            }
            case 1:
            {
                name="送礼";
                break;
            }
        }
        return name;
    }

    //收礼类别名称转换返回
    public String getnamesltype2()
    {
        String name = "";
        switch(type2)
        {
            case 0:
            {
                name="结婚大喜";
                break;
            }
            case 1:
            {
                name="新造华堂";
                break;
            }
            case 2:
            {
                name="金榜题名";
                break;
            }
        }
        return name;
    }
    //获取时间字符串（2020-12-22）
    public String getDateString()
    {
        String datearr="";
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        datearr=sdf.format(datetime);
        return datearr;
    }

    //获取时间字符串（2020-12-22）
    public String getDateString(String pattern)
    {
        String datearr="";
        SimpleDateFormat sdf=new SimpleDateFormat(pattern);
        datearr=sdf.format(datetime);
        return datearr;
    }
}
