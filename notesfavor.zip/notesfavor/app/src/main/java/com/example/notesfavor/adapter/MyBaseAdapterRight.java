package com.example.notesfavor.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.notesfavor.MainActivity;
import com.example.notesfavor.R;
import com.example.notesfavor.common.Favors;

import java.util.ArrayList;

public class MyBaseAdapterRight extends BaseAdapter {
    private ArrayList<Favors> list=null;
    private Context context;
    public MyBaseAdapterRight(Context context, ArrayList<Favors> list)
    {
        this.list=list;
        this.context=context;
    }
    //得到item的总数
    @Override
    public int getCount() {
        //返回ListView Item条目的总数
        int sum=0;
        if(list==null)
            sum=0;
        else
            sum=list.size();
        return sum;
    }
    //得到Item代表的对象
    @Override
    public Object getItem(int position) {
        //返回ListView Item条目代表的对象
        if(list==null)
            return null;
        else
            return list.get(position);
    }
    //得到Item的id
    @Override
    public long getItemId(int position) {
        //返回ListView Item的id
        return position;
    }
    //得到Item的View视图
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        //使用了懒汉模式
        if(convertView == null){
            //将list_item.xml文件找出来并转换成View对象
            convertView  = View.inflate(context, R.layout.list_item_right, null);
            convertView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,140));
            //找到list_item.xml中创建的TextView
            holder = new ViewHolder();
            holder.name = (TextView) convertView.findViewById(R.id.listitem_text_name);
            holder.type = (TextView) convertView.findViewById(R.id.listitem_text_type);
            holder.count = (TextView) convertView.findViewById(R.id.listitem_text_count);
            holder.date=(TextView)convertView.findViewById(R.id.listitem_text_date);
            holder.iconleft=(ImageView)convertView.findViewById(R.id.listitem_img_iconleft);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder) convertView.getTag();
        }
        Favors item=list.get(position);
        if(item!=null)
        {
            holder.name.setText(item.name);
            holder.type.setText(item.getnamesltype2());
            holder.count.setText("￥"+item.amount);
            holder.date.setText(item.getDateString());
        }
        holder.iconleft.setBackgroundResource(R.drawable.icon_left);
        return convertView;
    }
    static class ViewHolder{
        TextView name;
        TextView type;
        TextView count;
        TextView date;
        ImageView iconleft;
    }
}

