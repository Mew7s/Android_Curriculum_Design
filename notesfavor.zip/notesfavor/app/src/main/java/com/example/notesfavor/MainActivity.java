package com.example.notesfavor;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.notesfavor.adapter.MyBaseAdapterCenter;
import com.example.notesfavor.adapter.MyBaseAdapterLeft;
import com.example.notesfavor.adapter.MyBaseAdapterRight;
import com.example.notesfavor.common.Base;
import com.example.notesfavor.common.Favors;

import org.w3c.dom.Text;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    /***************************************************
     *              显示控件初始化
     ************************************************/
    private DatePicker datePicker;//日历控件
    private Toast m_toast=null;  //提示toast
    private LinearLayout tabbar_left;//底部导航“随礼”按钮
    private LinearLayout tabbar_center;//底部导航“主页”按钮
    private LinearLayout tabbar_right;//底部导航“收礼”按钮

    private LinearLayout page_left;     //随礼界面
    private LinearLayout page_center;   //主页
    private LinearLayout page_right;    //收礼

    private LinearLayout linear_barleft1;//底部导航栏“随礼”三个子部件
    private TextView text_barleft2;
    private TextView text_barleft3;

    private LinearLayout linear_barright1;//底部导航栏“收礼”三个子部件
    private TextView text_barright2;
    private TextView text_barright3;

    private ImageView img_add;      //新增按钮
    private ImageView img_topleft;  //标题栏增加按钮
    private ImageView img_topright; //标题栏菜单（搜索）按钮
    private TextView text_title;    //标题

    private LinearLayout linear_findleft;   //随礼搜索输入框容器（控制显示隐藏）
    private LinearLayout linear_findright;  //收礼搜索输入框容器
    private EditText edit_findleft;         //随礼搜索输入框
    private EditText edit_finderight;       //收礼搜索输入框

    private ListView lv_slleft;     //随礼列表
    private ListView lv_slright;    //收礼列表
    private ListView lv_home;       //首页当天记录

    private Dialog dialogselectdate=null;   //新增界面中时间选择弹窗
    private Dialog dialogeditfavors=null;   //新增子项输入界面

    private DatePicker dialog_select_datePicker=null;//新增界面中时间选择弹窗中的时间选择控件

    //新增子项输入界面中的控件定义
    private Spinner dialog_spinner_type1;//类别1（随礼、收礼）
    private Spinner dialog_spinner_type2;//类别2（结婚大喜、新造华堂、金榜题名）
    private EditText dialog_edit_name;//名称
    private TextView dialog_text_date;//显示日期的标签
    private LinearLayout dialog_linear_date;//日期图标的容器
    private EditText dialog_edit_count;//金额
    private EditText dialog_edit_msg;//备注信息
    private TextView dialog_but_delete;//删除按钮
    private TextView dialog_but_edit;//编辑按钮
    private TextView dialog_but_cancel;//取消按钮
    private TextView dialog_but_yes;//确定按钮

    /***********************************************************
     *              控制数据初始化
     **********************************************************/
    private int showpage=0; //当前显示的界面 0:主页 1:随礼  2:收礼
    private boolean isshowfindlinear[]={false,false,false};//是否显示输入搜索框0:随礼界面 1：收礼界面 2：主页
    private MyBaseAdapterRight adapter_listright=null;  //收礼列表适配器
    private MyBaseAdapterLeft adapter_listleft=null;    //随礼列表适配器
    private MyBaseAdapterCenter adapter_listcenter=null;//主页列表适配器
    private ArrayList<Favors> listright=null;   //收礼数据列表
    private ArrayList<Favors> listleft=null;    //随礼数据列表
    private ArrayList<Favors> listcenter=null;  //主页显示数据列表
    private Date selectdate;    //用于缓存时间 （主页选择的时间缓存）

    /*
    *搜索时 listleft列表为显示的列表，不在搜索内容里面的数据为了不显示
    * 需要先移动到缓存中列表findcache_left中
    *搜索结束后将缓存中的数据移动回去，
    * 但搜索时需要对listleft以及findcanche_left都进行遍历查看是否存在搜索内容，
    * 是搜索内容的子项移动到list_left中，不是移动到缓存findcache_left中
     */
    private ArrayList<Favors> findcache_center=null;    //主页搜索缓存列表（主页不纯在搜索功能 未使用）
    private ArrayList<Favors> findcache_left=null;      //随礼界面缓存列表
    private ArrayList<Favors> findcache_right=null;     //收礼界面缓存列表

    private Favors inputfavors=null;    //增加子项显示的值
    private Favors editfavors=null;     //修改子项
    private int listposition[]={0,0};   //链表位置下标（用于子项删除）
    private int dialogeditmode=0;         //子项输入界面当前运行的模式0 输入 1编辑
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //手机内存文件读写权限申请
        checkPermission();
        //判断创建手机中的保存文件夹
        Base.CheckFilePath();
        //初始化handler
        initHandler();
        //初始化数据
        initMsg();
        //初始化dialog
        initDialogSelectDate();//时间选择弹窗初始化
        initDialogEditFavors();//子项输入弹窗初始化
        //初始化显示界面
        initView();
        //刷新三个列表的显示
        Message message = handler.obtainMessage();
        message.what = 4;
        handler.sendMessage(message);
    }

    /*
        android studio中UI存在于主线程，大部分回调函数，点击事件，输入事件……都属于子线程
        子线程中如果直接更新主线程中的UI，可能会出现报错或者不执行，所以采用handler接收子线
        程发送的数据，而handler在主线程上可以直接对主线程的UI进行更新。（自我理解）

        msg.what通俗来讲是传输的标识，用于区分传输回来的是什么命令
     */
    private Handler handler;
    private  void initHandler()
    {
        handler = new Handler() {
            public void handleMessage(Message msg)
            {
                switch (msg.what)
                {
                    //显示时间选择弹窗
                    case 1:
                    {
                        //判断弹窗是否为空
                        if(dialogselectdate!=null)
                        {
                            //不为空显示
                            dialogselectdate.show();
                        }
                        else
                        {
                            //为空重新初始化
                            initDialogSelectDate();
                            dialogselectdate.show();
                        }
                        //设置时间选择弹窗中的原始时间
                        Calendar cal = Calendar.getInstance();
                        cal.setTimeInMillis(selectdate.getTime());
                        //cal.set()
                        dialog_select_datePicker.init(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), null);
                        break;
                    }
                    //显示新增子项弹窗
                    case 2:
                    {
                        int type=0;
                        //接收操作状态数据
                        if(msg.obj!=null)
                            type=(int)msg.obj;
                        //判断是否为空
                        if(dialogeditfavors!=null)
                        {
                            //不为空显示
                            dialogeditfavors.show();
                        }
                        else
                        {
                            //为空初始化再显示
                            initDialogEditFavors();
                            dialogeditfavors.show();
                        }
                        //新建输入添加
                        if(type==0)
                        {
                            //隐藏编辑、删除按钮
                            dialog_but_delete.setVisibility(View.GONE);
                            dialog_but_edit.setVisibility(View.GONE);
                            dialog_but_cancel.setVisibility(View.VISIBLE);
                            dialog_but_yes.setVisibility(View.VISIBLE);
                            //将所有控件设置为可用
                            dialog_spinner_type1.setEnabled(true);
                            dialog_spinner_type2.setEnabled(true);
                            dialog_edit_count.setEnabled(true);
                            dialog_edit_name.setEnabled(true);
                            dialog_linear_date.setEnabled(true);
                            dialog_text_date.setEnabled(true);
                            dialog_edit_msg.setEnabled(true);
                            //显示新增子项的默认信息
                            if(inputfavors!=null)
                            {
                                dialog_spinner_type1.setSelection(inputfavors.type);
                                dialog_spinner_type2.setSelection(inputfavors.type2);
                                dialog_edit_name.setText(inputfavors.name);
                                dialog_text_date.setText(inputfavors.getDateString());
                                dialog_edit_count.setText(""+inputfavors.amount);
                                dialog_edit_msg.setText(inputfavors.remarks);
                            }
                        }
                        //列表点击查看
                        else if(type==1)
                        {
                            //获取点击列表的数据
                            if(listposition[0]==0)//判断是不是主页列表的点击事件
                            {
                                editfavors=listcenter.get(listposition[1]);
                            }
                            else if(listposition[0]==1)//判断是不是随礼界面的点击事件
                            {
                                editfavors=listleft.get(listposition[1]);
                            }
                            else if(listposition[0]==2)//判断是不是收礼界面的点击事件
                            {
                                editfavors=listright.get(listposition[1]);
                            }
                            //隐藏确定、取消按钮
                            dialog_but_delete.setVisibility(View.VISIBLE);
                            dialog_but_edit.setVisibility(View.VISIBLE);
                            dialog_but_cancel.setVisibility(View.GONE);
                            dialog_but_yes.setVisibility(View.GONE);
                            //将控件设置为不可用的状态达到不可修改的效果
                            dialog_spinner_type1.setEnabled(false);
                            dialog_spinner_type2.setEnabled(false);
                            dialog_edit_count.setEnabled(false);
                            dialog_edit_name.setEnabled(false);
                            dialog_linear_date.setEnabled(false);
                            dialog_text_date.setEnabled(true);
                            dialog_edit_msg.setEnabled(false);
                            //显示点击数据的参数
                            if(editfavors!=null)
                            {
                                dialog_spinner_type1.setSelection(editfavors.type);//随礼、收礼类别设置
                                dialog_spinner_type2.setSelection(editfavors.type2);//"结婚大喜"……类别设置
                                dialog_edit_name.setText(editfavors.name);//名称设置
                                dialog_text_date.setText(editfavors.getDateString());//时间设置
                                dialog_edit_count.setText(""+editfavors.amount);//金额显示
                                dialog_edit_msg.setText(editfavors.remarks);//备注显示
                            }
                        }
                        break;
                    }
                    //显示toast信息提示
                    case 3:
                    {
                        //判断是否为空
                        if(m_toast!=null)
                        {
                            //不为空 结束上一次的调用 删除重新创建
                            try{
                                m_toast.cancel();
                                m_toast=null;
                            }catch (Exception e)
                            {
                                e.printStackTrace();
                            }
                        }
                        m_toast=Toast.makeText(MainActivity.this,"",Toast.LENGTH_LONG);
                        m_toast.setText((String)msg.obj);
                        m_toast.show();
                        break;
                    }
                    //刷新listview显示  保存文件
                    case 4:
                    {
                        //对随礼列表排序
                        sortlistleft();
                        //对收礼列表排序
                        sortlistright();
                        //对主页显示信息刷新
                        refreshlistcenter();
                        //刷新三个列表
                        adapter_listcenter.notifyDataSetChanged();
                        adapter_listleft.notifyDataSetChanged();
                        adapter_listright.notifyDataSetChanged();
                        //保存文件
                        savelistleft();
                        savelistright();
                        break;
                    }
                }
            }
        };
    }
    //初始化数据函数
    private void initMsg()
    {
        inputfavors=new Favors();
        //选择的时间初始化(当天时间)
        selectdate=new Date(System.currentTimeMillis());
        //搜索子项缓存初始化
        findcache_center=new ArrayList<>();//可能不会使用
        findcache_left=new ArrayList<>();
        findcache_right=new ArrayList<>();
        //三个界面数据列表初始化
        listright=new ArrayList<>();
        listleft=new ArrayList<>();
        listcenter=new ArrayList<>();
        //读取列表信息
        readlistleft();
        readlistright();
    }
    //界面控件初始化函数
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void initView()
    {
        //顶部标签初始化
        text_title=(TextView)findViewById(R.id.main_text_topcenter);
        img_add=(ImageView)findViewById(R.id.main_but_add);
        img_topleft=(ImageView)findViewById(R.id.main_img_topleft);
        img_topright=(ImageView)findViewById(R.id.main_img_topright);

        img_add.setOnClickListener(this);
        img_topright.setOnClickListener(this);
        img_topleft.setOnClickListener(this);
        //三个界面
        page_left=(LinearLayout)findViewById(R.id.main_page_slleft);
        page_center=(LinearLayout)findViewById(R.id.main_page_home);
        page_right=(LinearLayout)findViewById(R.id.main_page_slright);
        //底部按钮
        tabbar_left=(LinearLayout)findViewById(R.id.main_barleft);
        tabbar_center=(LinearLayout)findViewById(R.id.main_barcenter);
        tabbar_right=(LinearLayout)findViewById(R.id.main_barright);
        //按钮的文字（用于改变颜色）、
        linear_barleft1=(LinearLayout)findViewById(R.id.main_bartext_left2);
        text_barleft2=(TextView)findViewById(R.id.main_bartext_left1);
        text_barleft3=(TextView) findViewById(R.id.main_bartext_left3);
        linear_barright1=(LinearLayout)findViewById(R.id.main_bartext_right2);
        text_barright2=(TextView)findViewById(R.id.main_bartext_right1);
        text_barright3=(TextView) findViewById(R.id.main_bartext_right3);

        //底部导航标签的点击函数
        tabbar_left.setOnClickListener(this);
        tabbar_center.setOnClickListener(this);
        tabbar_right.setOnClickListener(this);
        //搜索输入框初始化
        linear_findleft=(LinearLayout)findViewById(R.id.main_linear_findleft);
        linear_findright=(LinearLayout)findViewById(R.id.main_linear_findright);
        edit_findleft=(EditText)findViewById(R.id.main_edit_findleft);
        edit_finderight=(EditText)findViewById(R.id.main_edit_findright);
        //输入框输入事件
        edit_findleft.addTextChangedListener(new TextWatcher() {
            ////输入改变前
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            //输入改变
            @Override
            public void onTextChanged(CharSequence charSequence, int index, int i1, int i2) {
                String findmsg=charSequence.toString();
                boolean ischange=false;//数组是否改变的标志
                if(findmsg.isEmpty())
                {
                    //搜索信息为空 将所有的节点缓存都移回到显示列表中
                    int sum=findcache_left.size();
                    for(int i=0;i<sum;i++)
                    {
                        ischange=true;
                        listleft.add(findcache_left.remove(0));//每次都是移动0节点无需对i进行自减
                    }
                }
                else
                {
                    for(int i=0;i<findcache_left.size();i++)
                    {
                        //是显示内容移动到显示列表中
                        if(findcache_left.get(i).isFindItem(findmsg))
                        {
                            ischange=true;
                            Favors item=findcache_left.remove(i);
                            i--;//删除当前遍历的列表需要减1，否者会跳过一个节点
                            listleft.add(item);
                        }
                    }
                    for(int i=0;i<listleft.size();i++)
                    {
                        //不是搜索内容 移动到缓存中
                        if(!listleft.get(i).isFindItem(findmsg))
                        {
                            ischange=true;
                            Favors item=listleft.remove(i);
                            i--;
                            findcache_left.add(item);
                        }
                    }
                }
                //发生修改 对显示数组进行排序 刷新显示
                if(ischange)
                {
                    Message message = handler.obtainMessage();
                    message.what = 4;
                    handler.sendMessage(message);
                }
            }
            //输入改变后
            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        //输入框输入事件
        edit_finderight.addTextChangedListener(new TextWatcher() {
            ////输入改变前
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            //输入改变
            @Override
            public void onTextChanged(CharSequence charSequence, int index, int i1, int i2) {
                String findmsg=charSequence.toString();
                boolean ischange=false;//数组是否改变的标志
                if(findmsg.isEmpty())
                {
                    //搜索信息为空 将所有的节点缓存都移回到显示列表中
                    int sum=findcache_right.size();
                    for(int i=0;i<sum;i++)
                    {
                        ischange=true;
                        listright.add(findcache_right.remove(0));//每次都是移动0节点无需对i进行自减
                    }
                }
                else
                {
                    for(int i=0;i<findcache_right.size();i++)
                    {
                        //是显示内容移动到显示列表中
                        if(findcache_right.get(i).isFindItem(findmsg))
                        {
                            ischange=true;
                            Favors item=findcache_right.remove(i);
                            i--;//删除当前遍历的列表需要减1，否者会跳过一个节点
                            listright.add(item);
                        }
                    }
                    for(int i=0;i<listright.size();i++)
                    {
                        //不是搜索内容 移动到缓存中
                        if(!listright.get(i).isFindItem(findmsg))
                        {
                            ischange=true;
                            Favors item=listright.remove(i);
                            i--;
                            findcache_right.add(item);
                        }
                    }
                }
                //发生修改 对显示数组进行排序 刷新显示
                if(ischange)
                {
                    Message message = handler.obtainMessage();
                    message.what = 4;
                    handler.sendMessage(message);
                }
            }
            //输入改变后
            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        //listView初始化
        lv_slleft=(ListView)findViewById(R.id.main_lv_left);
        lv_slright=(ListView)findViewById(R.id.main_lv_right);
        lv_home=(ListView)findViewById(R.id.main_lv_center);
        //listview适配器初始化
        adapter_listright=new MyBaseAdapterRight(getBaseContext(),listright);
        adapter_listleft=new MyBaseAdapterLeft(getBaseContext(),listleft);
        adapter_listcenter=new MyBaseAdapterCenter(getBaseContext(),listcenter);
        //list绑定适配器
        lv_slright.setAdapter(adapter_listright);
        lv_slleft.setAdapter(adapter_listleft);
        lv_home.setAdapter(adapter_listcenter);

        //收礼界面列表点击函数
        lv_slright.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.e("点击测试","你点击了:"+i);
                //记录下标
                listposition[0]=2;
                listposition[1]=i;
                //显示dilog弹窗
                Message message = handler.obtainMessage();
                message.what = 2;
                message.obj=(int)1;//显示模式设置（删除、编辑）
                handler.sendMessage(message);
            }
        });
        //随礼界面列表点击函数
        lv_slleft.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.e("点击测试","你点击了:"+i);
                //记录下标
                listposition[0]=1;
                listposition[1]=i;
                //显示dialog弹窗
                Message message = handler.obtainMessage();
                message.what = 2;
                message.obj=(int)1;//显示模式设置（删除、编辑）
                handler.sendMessage(message);
            }
        });

        //主页底部列表选项点击函数
        lv_home.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.e("点击测试","你点击了:"+i);
                listposition[0]=0;
                listposition[1]=i;
                Message message = handler.obtainMessage();
                message.what = 2;
                message.obj=(int)1;
                handler.sendMessage(message);
            }
        });
        //初始化日历
        datePicker = (DatePicker)findViewById(R.id.date_picker);
        datePicker.setCalendarViewShown(false);
        datePicker.setSpinnersShown(true);
        //初始化显示日期
        Calendar cal = Calendar.getInstance();
        datePicker.init(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), null);
        //日历选中函数
        datePicker.setOnDateChangedListener(new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker datePicker, int i, int i1, int i2) {
                //修改日期
                selectdate=Base.getDate(""+datePicker.getYear()+"-"+(datePicker.getMonth()+1)+"-"+datePicker.getDayOfMonth());
                //刷新三个列表的显示
                Message message = handler.obtainMessage();
                message.what = 4;
                handler.sendMessage(message);
            }
        });
        //隐藏日历的表头
        hidedatepickerhead();
        //显示界面初始化（隐藏随礼和收礼界面）
        page_right.setVisibility(View.GONE);
        page_left.setVisibility(View.GONE);
    }
    //保存随礼列表信息
    private void savelistleft()
    {
        String savemsg="";
        //保存显示列表中的数据
        for(int i=0;i<listleft.size();i++)
        {
            savemsg+=listleft.get(i).toString();
        }
        //保存缓存中的数据
        for(int i=0;i<findcache_left.size();i++)
        {
            savemsg+=findcache_left.get(i).toString();
        }
        Base.writefile(Base.filepath+"/listleft.txt",savemsg);
    }
    //保存收礼列表
    private void savelistright()
    {
        String savemsg="";
        //保存显示列表中的数据
        for(int i=0;i<listright.size();i++)
        {
            savemsg+=listright.get(i).toString();
        }
        //保存缓存中的数据
        for(int i=0;i<findcache_right.size();i++)
        {
            savemsg+=findcache_right.get(i).toString();
        }
        Base.writefile(Base.filepath+"/listright.txt",savemsg);
    }
    //读取文件listleft
    private void readlistleft()
    {
        String readmsg=Base.readfile(Base.filepath+"/listleft.txt");
        String list[]=readmsg.split("#favor#");
        for(int i=0;i<list.length;i++)
        {
            if(list[i]!=null&&!list[i].isEmpty()) {
                Favors item = new Favors();
                item.analysis(list[i]);
                listleft.add(item);
            }
        }
    }
    //读取文件listleft
    private void readlistright()
    {
        String readmsg=Base.readfile(Base.filepath+"/listright.txt");
        String list[]=readmsg.split("#favor#");
        for(int i=0;i<list.length;i++)
        {
            if(list[i]!=null&&!list[i].isEmpty()) {
                Favors item = new Favors();
                item.analysis(list[i]);
                listright.add(item);
            }
        }
    }
    //对随礼的列表进行排序 倒序
    private void sortlistleft()
    {
        if(listleft==null)
            return;
        int sum=listleft.size();
        int minindex=0;//最旧日期的下标
        for(int i=0;i<sum;i++)
        {
            minindex=i;
            for(int j=i;j<sum;j++)
            {
                if(listleft.get(minindex).datetime.getTime()>listleft.get(j).datetime.getTime())
                {
                    minindex=j;
                }
            }
            //把最小的移动到最前面
            Favors item=listleft.remove(minindex);
            listleft.add(0,item);
        }
    }

    //对收礼的列表进行排序 倒序
    private void sortlistright()
    {
        if(listright==null)
            return;
        int sum=listright.size();
        int minindex=0;//最旧日期的下标
        for(int i=0;i<sum;i++)
        {
            minindex=i;
            for(int j=i;j<sum;j++)
            {
                if(listright.get(minindex).datetime.getTime()>listright.get(j).datetime.getTime())
                {
                    minindex=j;
                }
            }
            //把最小的移动到最前面
            Favors item=listright.remove(minindex);
            listright.add(0,item);
        }
    }
    //对主页的内容进行刷新
    private void refreshlistcenter()
    {
        //获取当日日期
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        String datestring=sdf.format(selectdate);
        //删除所有的子节点
        int sum=listcenter.size();
        for(int i=0;i<sum;i++)
        {
            Favors item=listcenter.remove(0);
            item=null;
        }
        //遍历随礼列表判断是否存在当天的记录
        sum=listleft.size();
        for(int i=0;i<sum;i++)
        {
            if(datestring.indexOf(listleft.get(i).getDateString())!=-1)
            {
                //字节引用修改时直接修改
                listcenter.add(listleft.get(i));
            }
        }
        //遍历随礼缓存列表列表判断是否存在当天的记录
        sum=findcache_left.size();
        for(int i=0;i<sum;i++)
        {
            if(datestring.indexOf(findcache_left.get(i).getDateString())!=-1)
            {
                //字节引用修改时直接修改
                listcenter.add(findcache_left.get(i));
            }
        }
        //遍历收礼列表判断是否存在当天的记录
        sum=listright.size();
        for(int i=0;i<sum;i++)
        {
            if(datestring.indexOf(listright.get(i).getDateString())!=-1)
            {
                //字节引用修改时直接修改
                listcenter.add(listright.get(i));
            }
        }
        //遍历随礼缓存列表列表判断是否存在当天的记录
        sum=findcache_right.size();
        for(int i=0;i<sum;i++)
        {
            if(datestring.indexOf(findcache_right.get(i).getDateString())!=-1)
            {
                //字节引用修改时直接修改
                listcenter.add(findcache_right.get(i));
            }
        }
        //应为都是当天的数据所以无需对listcenter进行排序
    }

    //隐藏首页日历选择器的头部
    private void hidedatepickerhead()
    {
        ViewGroup rootView = (ViewGroup) datePicker.getChildAt(0);
        if (rootView == null)
            return;
        View headerView = rootView.getChildAt(0);
        if (headerView == null)
            return;
        headerView.setVisibility(View.GONE);
    }
    //文件读写权限检查及申请
    int PERMISSION_REQUEST_CODE = 0x10;
    private void checkPermission() {
        //较低版本android系统权限动态申请
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED)
        {
            //用户已经拒绝过一次，再次弹出权限申请对话框需要给用户一个解释
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            {
                Toast.makeText(this, "请开通相关权限，否则无法正常使用本应用！", Toast.LENGTH_SHORT).show();
            }
            //申请权限
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        }
        else
        {
            Log.e("", "checkPermission: 已经授权！");
        }
        //高版本android系统权限动态申请
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            {
                if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE))
                {
                    ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            777);
                }
            }
        }
    }

    //初始化时间选择弹窗
    private void initDialogSelectDate()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        View view = View.inflate(MainActivity.this, R.layout.date_time_dialog, null);
        TextView title=(TextView)view.findViewById(R.id.date_title);
        dialog_select_datePicker = (DatePicker) view.findViewById(R.id.date_picker);
        builder.setView(view);
        dialog_select_datePicker.setCalendarViewShown(false);
        dialog_select_datePicker.setSpinnersShown(true);
        title.setText("请选择结束时间");

        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(selectdate.getTime());
        //cal.set()
        dialog_select_datePicker.init(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), null);
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }});
        builder.setPositiveButton("确  定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog_text_date.setText(""+dialog_select_datePicker.getYear()+"-"+(dialog_select_datePicker.getMonth()+1)+"-"+dialog_select_datePicker.getDayOfMonth());
                dialog.cancel();
            }});
        dialogselectdate = builder.create();

    }
    //初始化子项输入弹窗
    private void initDialogEditFavors()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        View view = View.inflate(MainActivity.this, R.layout.dialog_additem, null);
        dialog_spinner_type1=(Spinner)view.findViewById(R.id.dialog_spinner_type1);
        dialog_spinner_type2=(Spinner)view.findViewById(R.id.dialog_spinner_type2);
        dialog_edit_name=(EditText)view.findViewById(R.id.dialog_edit_name);
        dialog_text_date=(TextView)view.findViewById(R.id.dialog_text_date);
        dialog_linear_date=(LinearLayout)view.findViewById(R.id.dialog_linear_date);
        dialog_edit_count=(EditText)view.findViewById(R.id.dialog_edit_count);
        dialog_edit_msg=(EditText)view.findViewById(R.id.dialog_edit_msg);
        dialog_but_delete=(TextView)view.findViewById(R.id.dialog_but_delete);
        dialog_but_edit=(TextView)view.findViewById(R.id.dialog_but_edit);
        dialog_but_cancel=(TextView)view.findViewById(R.id.dialog_but_cancel);
        dialog_but_yes=(TextView)view.findViewById(R.id.dialog_but_yes);
        //隐藏编辑删除按钮
        dialog_but_delete.setVisibility(View.GONE);
        dialog_but_edit.setVisibility(View.GONE);
        dialog_but_cancel.setVisibility(View.VISIBLE);
        dialog_but_yes.setVisibility(View.VISIBLE);
        dialog_spinner_type1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Log.e("选择测试","你选择了"+i);
                if(i==0)
                {
                    dialog_spinner_type2.setEnabled(false);
                }
                else
                {
                    dialog_spinner_type2.setEnabled(true);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        dialog_but_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name=dialog_edit_name.getText().toString();
                if(name==null||name.isEmpty())
                {
                    Message message = handler.obtainMessage();
                    message.what = 3;
                    message.obj="请输入名称！";
                    handler.sendMessage(message);
                    return;
                }
                //输入状态下
                if(dialogeditmode==0)
                {
                    Favors inputfavors=new Favors();
                    inputfavors.type=dialog_spinner_type1.getSelectedItemPosition();
                    inputfavors.type2=dialog_spinner_type2.getSelectedItemPosition();
                    inputfavors.name=dialog_edit_name.getText().toString();
                    inputfavors.datetime=Base.getDate(dialog_text_date.getText().toString());
                    inputfavors.amount=Double.parseDouble(dialog_edit_count.getText().toString()) ;
                    inputfavors.remarks=dialog_edit_msg.getText().toString();
                    if(inputfavors.type==0)
                    {
                        Log.e("添加子项测试","主页");
                        listleft.add(0,inputfavors);
                    }
                    else if(inputfavors.type==1)
                    {
                        Log.e("添加子项测试","随礼");
                        listright.add(0,inputfavors);
                    }
                }
                else
                {
                    if(listposition[0]==0)
                    {
                        editfavors=listcenter.get(listposition[1]);
                    }
                    else if(listposition[0]==1)
                    {
                        editfavors=listleft.get(listposition[1]);
                    }
                    else if(listposition[0]==2)
                    {
                        editfavors=listright.get(listposition[1]);
                    }
                    editfavors.type=dialog_spinner_type1.getSelectedItemPosition();
                    editfavors.type2=dialog_spinner_type2.getSelectedItemPosition();
                    editfavors.name=dialog_edit_name.getText().toString();
                    editfavors.datetime=Base.getDate(dialog_text_date.getText().toString());
                    editfavors.amount=Double.parseDouble(dialog_edit_count.getText().toString()) ;
                    editfavors.remarks=dialog_edit_msg.getText().toString();
                }
                //初始化模式标志
                dialogeditmode=0;
                //刷先listview的显示 保存信息
                Message message = handler.obtainMessage();
                message.what = 4;
                handler.sendMessage(message);
                //关闭界面
                dialogeditfavors.dismiss();
            }
        });
        dialog_but_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog_but_delete.setVisibility(View.GONE);
                dialog_but_edit.setVisibility(View.GONE);
                dialog_but_cancel.setVisibility(View.VISIBLE);
                dialog_but_yes.setVisibility(View.VISIBLE);
                dialog_spinner_type1.setEnabled(true);
                dialog_spinner_type2.setEnabled(true);
                dialog_edit_count.setEnabled(true);
                dialog_edit_name.setEnabled(true);
                dialog_linear_date.setEnabled(true);
                dialog_text_date.setEnabled(true);
                dialog_edit_msg.setEnabled(true);
                //修改模式标志
                dialogeditmode=1;
            }
        });
        dialog_but_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(listposition[0]==0)
                {
                    Favors item=listcenter.remove(listposition[1]);
                    //查找到原始数据所在的位置 进行删除
                    if(item.type==0)
                    {
                        int sum=listleft.size();
                        for(int i=0;i<sum;i++)
                        {
                            if(listleft.get(i)==item)
                            {
                                listleft.remove(i);
                                break;
                            }
                        }
                    }
                    else
                    {
                        int sum=listright.size();
                        for(int i=0;i<sum;i++)
                        {
                            if(listright.get(i)==item)
                            {
                                listright.remove(i);
                                break;
                            }
                        }
                    }
                    item=null;
                }
                else if(listposition[0]==1)
                {
                    Favors item=listleft.remove(listposition[1]);
                    item=null;
                }
                else if(listposition[0]==2)
                {
                    Favors item=listright.remove(listposition[1]);
                    item=null;
                }
                //刷新listview显示 保存信息
                Message message = handler.obtainMessage();
                message.what = 4;
                handler.sendMessage(message);
                dialogeditfavors.dismiss();
            }
        });
        dialog_but_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogeditfavors.dismiss();
                //初始化模式标志
                dialogeditmode=0;
            }
        });
        //日期图标点击事件
        dialog_linear_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectdate=Base.getDate(dialog_text_date.getText().toString());
                Message message = handler.obtainMessage();
                message.what = 1;
                handler.sendMessage(message);
            }
        });

        builder.setView(view);
        dialogeditfavors = builder.create();
    }

    //根据标志刷新搜索输入框的显示
    private void refreshfindlinear()
    {
        switch(showpage)
        {
            case 0:
            {
                Message message = handler.obtainMessage();
                message.what = 3;
                message.obj="无效按键";
                handler.sendMessage(message);
                break;
            }
            case 1:
            {
                //判断标志显示隐藏随礼的搜索输入框子界面
                if(isshowfindlinear[0])
                    linear_findleft.setVisibility(View.VISIBLE);
                else
                    linear_findleft.setVisibility(View.GONE);
                //清空随礼搜索输入框中的内容
                edit_findleft.setText("");
                break;
            }
            case 2:
            {
                //判断标志显示隐藏收礼的搜索输入框子界面
                if(isshowfindlinear[1])
                    linear_findright.setVisibility(View.VISIBLE);
                else
                    linear_findright.setVisibility(View.GONE);
                //清空收礼搜索输入框中的内容
                edit_finderight.setText("");
                break;
            }
        }
    }
    //点击函数
    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.main_barleft:
            {
                //修改显示标志
                showpage=1;
                //显示界面
                page_left.setVisibility(View.VISIBLE);
                page_center.setVisibility(View.GONE);
                page_right.setVisibility(View.GONE);
                //修改tabbar
                linear_barleft1.setBackgroundResource(R.drawable.bg_bk_cricular2);
                text_barleft2.setTextColor(Color.parseColor("#0DB09B"));
                text_barleft3.setTextColor(Color.parseColor("#0DB09B"));
                linear_barright1.setBackgroundResource(R.drawable.bg_bk_circular);
                text_barright2.setTextColor(Color.parseColor("#858585"));
                text_barright3.setTextColor(Color.parseColor("#858585"));
                //设置标题
                text_title.setText("随礼");
                //修改搜索按钮
                img_topright.setBackgroundResource(R.drawable.icon_find);
                break;
            }
            case R.id.main_barcenter:
            {
                //修改显示标志
                showpage=0;
                page_left.setVisibility(View.GONE);
                page_center.setVisibility(View.VISIBLE);
                page_right.setVisibility(View.GONE);
                //修改底部导航栏的字体颜色
                linear_barleft1.setBackgroundResource(R.drawable.bg_bk_circular);
                text_barleft2.setTextColor(Color.parseColor("#858585"));
                text_barleft3.setTextColor(Color.parseColor("#858585"));
                linear_barright1.setBackgroundResource(R.drawable.bg_bk_circular);
                text_barright2.setTextColor(Color.parseColor("#858585"));
                text_barright3.setTextColor(Color.parseColor("#858585"));
                //设置标题
                text_title.setText("主页");
                //修改搜索按钮
                img_topright.setBackgroundResource(R.drawable.icon_menu);
                break;
            }
            case R.id.main_barright:
            {
                //修改显示标志
                showpage=2;
                page_left.setVisibility(View.GONE);
                page_center.setVisibility(View.GONE);
                page_right.setVisibility(View.VISIBLE);
                //修改底部导航栏的字体颜色
                linear_barleft1.setBackgroundResource(R.drawable.bg_bk_circular);
                text_barleft2.setTextColor(Color.parseColor("#858585"));
                text_barleft3.setTextColor(Color.parseColor("#858585"));
                linear_barright1.setBackgroundResource(R.drawable.bg_bk_cricular2);
                text_barright2.setTextColor(Color.parseColor("#0DB09B"));
                text_barright3.setTextColor(Color.parseColor("#0DB09B"));
                //设置标题
                text_title.setText("收礼");
                //修改搜索按钮
                img_topright.setBackgroundResource(R.drawable.icon_find);
                break;
            }
            case R.id.main_img_topleft:
            {
                if(inputfavors==null)
                    inputfavors=new Favors();
                Log.e("获取日期",""+datePicker.getYear()+"-"+(datePicker.getMonth()+1)+"-"+datePicker.getDayOfMonth());
                inputfavors.datetime=Base.getDate(""+datePicker.getYear()+"-"+(datePicker.getMonth()+1)+"-"+datePicker.getDayOfMonth());
                if(showpage==1)
                    inputfavors.type=0;
                else  if(showpage==2)
                    inputfavors.type=1;
                inputfavors.name="";
                inputfavors.amount=0;
                inputfavors.remarks="";
                Message message = handler.obtainMessage();
                message.what = 2;
                message.obj=(int)0;
                handler.sendMessage(message);
                break;
            }
            case R.id.main_img_topright:
            {
                if(showpage==1)
                    isshowfindlinear[0]=!isshowfindlinear[0];
                else if(showpage==2)
                    isshowfindlinear[1]=!isshowfindlinear[1];
                else if(showpage==0)
                    isshowfindlinear[2]=!isshowfindlinear[2];
                refreshfindlinear();
                break;
            }
            case R.id.main_but_add:
            {
                if(inputfavors==null)
                    inputfavors=new Favors();
                Log.e("获取日期",""+datePicker.getYear()+"-"+(datePicker.getMonth()+1)+"-"+datePicker.getDayOfMonth());
                inputfavors.datetime=Base.getDate(""+datePicker.getYear()+"-"+(datePicker.getMonth()+1)+"-"+datePicker.getDayOfMonth());
                if(showpage==1)
                    inputfavors.type=0;
                else  if(showpage==2)
                    inputfavors.type=1;
                inputfavors.name="";
                inputfavors.amount=0;
                inputfavors.remarks="";
                Message message = handler.obtainMessage();
                message.what = 2;
                message.obj=(int)0;
                handler.sendMessage(message);
                break;
            }
        }
    }
}
