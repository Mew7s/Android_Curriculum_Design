package com.example.notesfavor.common;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.util.TypedValue;
import android.widget.LinearLayout;

import androidx.annotation.ColorInt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

public class Base {
    //字符串转date
    public static Date getDate(String str) {
        Date date=new Date();
        try {
            java.text.SimpleDateFormat formatter = new SimpleDateFormat(
                    "yyyy-MM-dd");
            date = formatter.parse(str);

        } catch (Exception e) {
            // TODO: handle exception
        }
        return date;
    }
    //文件选择的解析
    public static String getPath(Context context, Uri uri)
    {
        if ("content".equalsIgnoreCase(uri.getScheme())) {
            String[] projection = { "_data" };
            Cursor cursor = null;
            try {
                cursor = context.getContentResolver().query(uri, projection, null, null, null);
                int column_index = cursor.getColumnIndexOrThrow("_data");
                if (cursor.moveToFirst()) {
                    return cursor.getString(column_index);
                }
            } catch (Exception e) {
                // Eat it  Or Log it.
            }
        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }
        return null;
    }

    public static String filepath;
    //检测文件夹是否存在 不存在创建
    public static void CheckFilePath()
    {
        filepath="data/data/com.example.notesfavor";
        Log.e("文件夹路径",filepath);
        if(!isExist(filepath+"/listleft.txt"))
            mkFile(filepath,"listleft.txt");
        if(!isExist(filepath+"/listright.txt"))
            mkFile(filepath,"listright.txt");
    }
    //文件读写函数
    public static void writefile(String filepath,String msg)
    {
        //写入数据
        FileOutputStream outputStream = null;
        try {
            //增加模式写入数据
            outputStream = new FileOutputStream(filepath);
            try {
                outputStream.write(msg.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public static void writefile(String filepath,byte[] msg)
    {
        //写入数据
        FileOutputStream outputStream = null;
        try {
            //outputStream = new FileOutputStream(filepath,true);//增加模式写入数据
            outputStream = new FileOutputStream(filepath);
            try {
                outputStream.write(msg);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public static byte[] readfile_byte(String filepath)
    {
        byte[]  bSmall=new byte[2];
        File file = new File(filepath);
        long fileSize = file.length();
        if (fileSize > Integer.MAX_VALUE)
        {
            System.out.println("file too big...");
            return bSmall;
        }
        FileInputStream fi = null;
        try
        {
            fi = new FileInputStream(file);
            bSmall=null;
            bSmall = new byte[(int) fileSize];
            int offset = 0;
            int numRead = 0;
            while (offset <bSmall.length
                    && (numRead = fi.read(bSmall, offset, bSmall.length - offset)) >= 0) {
                offset += numRead;
            }
            // 确保所有数据均被读取
            if (offset != bSmall.length) {
                throw new IOException("Could not completely read file "
                        + file.getName());
            }
            fi.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bSmall;
    }
    public static ArrayList<String> getFilesAllName(String path) {
        File file=new File(path);
        File[] files=file.listFiles();
        if (files == null){Log.e("error","空目录");return null;}
        ArrayList<String> s = new ArrayList<>();
        for(int i =0;i<files.length;i++){
            s.add(files[i].getAbsolutePath());
        }
        return s;
    }

    public static String readfile(String filepath)
    {
        String msg="";
        if(!isExist(filepath))
            return msg;
        File fileopen = new File(filepath);
        try {
            InputStream instream = new FileInputStream(fileopen);
            if (instream != null)
            {
                InputStreamReader inputreader = new InputStreamReader(instream);
                BufferedReader buffreader = new BufferedReader(inputreader);
                String line;
                // 分行读取
                while (( line = buffreader.readLine()) != null) {
                    //Log.d("读取到文件内容",line);
                    msg=msg+line;
                }
                instream.close();
            }
        }
        catch (FileNotFoundException e)
        {
            Log. d ("TestFile", "文件不存在");
            e.printStackTrace();
        }
        catch (IOException e)
        {
            Log. d ("TestFile", e.getMessage());
        }
        return msg;
    }
    public static boolean isExist(String filepath)
    {
        File file=new File(filepath);
        return file.exists();
    }

    public static boolean delete(String delFile) {
        File file = new File(delFile);
        if (!file.exists()) {

            return false;
        } else {
            if (file.isFile())
                return deleteSingleFile(delFile);
            else
                return deleteDirectory(delFile);
        }
    }
    public static boolean deleteSingleFile(String filePath$Name) {
        File file = new File(filePath$Name);
        // 如果文件路径所对应的文件存在，并且是一个文件，则直接删除
        if (file.exists() && file.isFile()) {
            if (file.delete()) {
                System.out.println("Copy_Delete.deleteSingleFile: 删除单个文件" + filePath$Name + "成功！");
                return true;
            } else {
                System.out.println("删除单个文件" + filePath$Name + "失败！");
                return false;
            }
        } else {
            System.out.println("删除单个文件失败：" + filePath$Name + "不存在！");
            return false;
        }
    }

    public static boolean deleteDirectory(String filePath) {
        // 如果dir不以文件分隔符结尾，自动添加文件分隔符
        if (!filePath.endsWith(File.separator))
            filePath = filePath + File.separator;
        File dirFile = new File(filePath);
        // 如果dir对应的文件不存在，或者不是一个目录，则退出
        if ((!dirFile.exists()) || (!dirFile.isDirectory())) {
            System.out.println("删除目录失败：" + filePath + "不存在！");
            return false;
        }
        boolean flag = true;
        // 删除文件夹中的所有文件包括子目录
        File[] files = dirFile.listFiles();
        for (File file : files) {
            // 删除子文件
            if (file.isFile()) {
                flag = deleteSingleFile(file.getAbsolutePath());
                if (!flag)
                    break;
            }
            // 删除子目录
            else if (file.isDirectory()) {
                flag = deleteDirectory(file
                        .getAbsolutePath());
                if (!flag)
                    break;
            }
        }
        if (!flag)
        {
            System.out.println("删除目录失败！");
            return false;
        }
        // 删除当前目录
        if (dirFile.delete())
        {
            System.out.println("Copy_Delete.deleteDirectory: 删除目录" + filePath + "成功！");
            return true;
        } else {
            System.out.println("删除目录：" + filePath + "失败！");
            return false;
        }
    }
    public static void mkFile(String filename)
    {
        File fileCreate=new File(filename);
        if(!fileCreate.exists())
        {
            try {
                fileCreate.createNewFile();
                Log.d("文件创建","成功");
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("文件创建","失败"+e);
            }
        }
        else{
            Log.d("文件创建","已存在");
        }
    }
    public static void mkFile(String filepath,String filename)
    {
        //判断路径是否存在
        File file=new File(filepath);
        if(!file.exists())
        {
            if (file.mkdirs())
            {
                Log.d("文件夹创建", "成功");
            }
            else
            {
                Log.d("文件夹创建", "失败");
            }
        }
        else
        {
            Log.d("文件夹创建","已存在");
        }
        //文件创建
        File fileCreate=new File((filepath+"/"+filename));
        if(!fileCreate.exists())
        {
            try {
                fileCreate.createNewFile();
                Log.d("文件创建","成功");
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("文件创建","失败"+e);
            }
        }
        else{
            Log.d("文件创建","已存在");
        }
    }
    public static boolean mkfilepath(String filepath)
    {
        //判断路径是否存在
        File file=new File(filepath);
        if(!file.exists())
        {
            if (file.mkdirs())
            {
                Log.d("文件夹创建", "成功");
                return true;
            }
            else
            {
                Log.d("文件夹创建", "失败");
                return false;
            }
        }
        else
        {
            Log.d("文件夹创建","已存在");
            return true;
        }
    }
}