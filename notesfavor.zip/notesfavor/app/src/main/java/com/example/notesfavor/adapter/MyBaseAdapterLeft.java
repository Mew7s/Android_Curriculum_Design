package com.example.notesfavor.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.notesfavor.MainActivity;
import com.example.notesfavor.R;
import com.example.notesfavor.common.Favors;

import java.util.ArrayList;

public class MyBaseAdapterLeft extends BaseAdapter {
    private ArrayList<Favors> list=null;
    private Context context;
    public MyBaseAdapterLeft(Context context, ArrayList<Favors> list)
    {
        this.list=list;
        this.context=context;
    }
    //得到item的总数
    @Override
    public int getCount() {
        //返回ListView Item条目的总数
        int sum=0;
        if(list==null)
            sum=0;
        else
            sum=list.size();
        return sum;
    }
    //得到Item代表的对象
    @Override
    public Object getItem(int position) {
        //返回ListView Item条目代表的对象
        if(list==null)
            return null;
        else
            return list.get(position);
    }
    //得到Item的id
    @Override
    public long getItemId(int position) {
        //返回ListView Item的id
        return position;
    }
    //得到Item的View视图
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        ViewHolder holder = null;
        //使用了懒汉模式
        if(convertView == null){
            //将list_item.xml文件找出来并转换成View对象
            convertView  = View.inflate(context, R.layout.list_item_left, null);
            convertView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,140));
            //找到list_item.xml中创建的TextView
            holder = new ViewHolder();
            holder.linearmain=(LinearLayout)convertView.findViewById(R.id.listitem_left_main);
            holder.name = (TextView) convertView.findViewById(R.id.listitem_left_name);
            holder.dateday = (TextView) convertView.findViewById(R.id.listitem_left_dateday);
            holder.datemonth=(TextView)convertView.findViewById(R.id.listitem_left_datemonth);
            holder.count = (TextView) convertView.findViewById(R.id.listitem_left_count);
            holder.iconleft=(ImageView)convertView.findViewById(R.id.listitem_left_iconleft);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder) convertView.getTag();
        }
        Favors item=list.get(position);
        if(item!=null)
        {
            holder.name.setText(item.name);
            holder.dateday.setText(""+item.getDateString("dd"));
            holder.datemonth.setText(""+item.getDateString("MM")+"月");
            holder.count.setText("￥"+item.amount);
        }
        holder.iconleft.setBackgroundResource(R.drawable.icon_left);
        return convertView;
    }
    static class ViewHolder{
        LinearLayout linearmain;
        TextView name;
        TextView dateday;
        TextView datemonth;
        TextView count;
        ImageView iconleft;
    }
}

